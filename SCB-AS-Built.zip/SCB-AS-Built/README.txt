﻿************************************************
Dell EMC System As-Built Documentation
prepared for Standard Chartered PLC
************************************************

To view this documentation, double-click the
index.htm file in this folder. The documentation
will open in your default browser.

For issues with this documentation, please contact
docfeedback@vce.com.

(C)2020 2018 Dell Inc. or its
subsidiaries. All Rights Reserved.
